# CMake_Tutorial
The repositoy which contains 5 demos,elaborates how to write CMAKE in details.

# Tutorial Vedios:
 https://www.bilibili.com/video/BV16V411k7eF?from=search&seid=11310198288494275879

# Copyright:
 ClangWU  SCUT 
 Email:clangwu@163.com
