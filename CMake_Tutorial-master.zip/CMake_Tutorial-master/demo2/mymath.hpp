#ifndef MYMATH_H
#define MYMATH_H

double power(double,double);

#endif
